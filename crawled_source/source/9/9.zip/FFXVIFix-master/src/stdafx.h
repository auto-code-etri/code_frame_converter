#pragma once

#define WIN32_LEAN_AND_MEAN

#include <cassert>
#include <windows.h>
#include <fstream>
#include <iostream>
#include <inttypes.h>
#include <filesystem>
#include <string>