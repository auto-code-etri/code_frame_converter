import NativeExampleTurboModule from './NativeExampleTurboModule'

export const ExampleTurboModule = NativeExampleTurboModule
