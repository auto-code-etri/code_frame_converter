//
//  MGLExampleTurboModule.h
//  NitroExample
//
//  Created by Marc Rousavy on 13.11.24.
//

#import <Foundation/Foundation.h>
#import <ExampleTurboModule/ExampleTurboModule.h>

NS_ASSUME_NONNULL_BEGIN

@interface ExampleTurboModule : NSObject <NativeExampleTurboModuleSpec>

@end

NS_ASSUME_NONNULL_END
