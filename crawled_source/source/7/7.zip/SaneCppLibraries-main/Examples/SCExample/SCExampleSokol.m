// Copyright (c) Stefano Cristiano
// SPDX-License-Identifier: MIT
#include "SCExampleSokol.c"
