@page page_platforms Platforms

Supported:  
✅ macOS 13.6+ (Ventura) and iOS 14.0+
✅ Windows (10+)  
✅ Linux (Kernel 5.x+)

Planned:  
🔮 WASM (Emscripten / WASI)

Not Planned:  
❓ Android
