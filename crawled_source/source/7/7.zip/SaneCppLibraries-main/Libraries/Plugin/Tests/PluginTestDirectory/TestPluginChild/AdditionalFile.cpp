// Copyright (c) Stefano Cristiano
// SPDX-License-Identifier: MIT
#include <Libraries/Plugin/PluginMacros.h>
#include <Libraries/Strings/Console.h>
#include <Libraries/Strings/String.h>

SC::StringView externallyDefinedFunc() { return "Yeah"; }
