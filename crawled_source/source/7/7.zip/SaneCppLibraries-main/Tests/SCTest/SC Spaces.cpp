// The only reason why this file exists is to test that build system can handle spaces in files
