#ifndef GEN_CLIENT_H
#define GEN_CLIENT_H

void *get_function_pointer(const char *function_name);
#endif